package EM;

import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Tratamento implements Identificavel {

	@Id
	@GeneratedValue(generator="tratamento_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="tratamento_seq")
	private Long idTratamento;
	private String medicamento;
	
			
	public Long getIdTratamento() {
		return idTratamento;
	}
	public void setIdPessoa(Long idPessoa) {
		this.idTratamento = idTratamento;
	}
	
	public String getMedicamento() {
		return medicamento;
	}
	public void setMedicamento(String medicamento) {
		this.medicamento = medicamento;
	}
	
	
	
	
	
	
}
