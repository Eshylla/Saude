package EM;

import java.util.List;

import br.edu.ifpb.esperanca.daw2.ifoto.entities.Campanha;

public class CampanhaDAO extends DAO< Campanha > {
	
	public CampanhaDAO() {
		super(Campanha.class);
	}

	public List<Campanha> findBy(CampanahFiltro filtro) {
		return null;
	}
	
}
