package EM;

public class CampanhaDAO extends DAO<Campanha > {
	
	public CampanhaDAO() {
		super(Campanha.class);
	}

}
