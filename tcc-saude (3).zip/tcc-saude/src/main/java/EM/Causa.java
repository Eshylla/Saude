package EM;

public class Causa implements Identificavel {

}
