package EM;

public class Causa {

}
