package EM;

import  java.util.List ;

import  javax.enterprise.context.ApplicationScoped ;
import  javax.inject.Inject ;
import  javax.persistence.EntityManager ;
import  javax.persistence.Query ;

import  br.edu.ifpb.esperanca.daw2.ifoto.entities.Identificavel ;

@ApplicationScoped
 classe abstrata  pública DAO <E extends Identificavel > {  

	@Injetar
	private  EntityManager em;

	 classe privada < E > classe;

	 DAO público ( Classe < E >  classe ) {
		isso . classe = classe;
	}

	public  void  save ( E  obj ) {
		if (obj . getId () ==  null ) {
			em . persist (obj);
		} mais {
			atualização (obj);
		}
	}

	 atualização pública E  ( E obj ) { 
		E resultado = obj;
		resultado = em . mesclar (obj);
		return resultado;
	}

	public  void  remove ( E  obj ) {
		obj = getByID (obj . getId ());
		em . remove (obj);
	}

	public  E  getByID ( Long  objId ) {
		retornar em . find (classe, objId);
	}

	public  List < E >  getAll () {
		Consulta de consulta = em . createQuery ( " de "  + classe . getSimpleName ());
		consulta de retorno . getResultList ();
	}

}